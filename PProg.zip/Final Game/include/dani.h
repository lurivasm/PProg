/************************************************/
/*              PPROG VIDEOGAME                 */
/*         DREAM OF A JAVITI'S NIGHT            */
/*                                              */
/*  Members of the group:                       */
/*           - Javier Martínez                  */
/*           - Lucía Rivas                      */
/*           - Daniel Santo-Tomás               */
/*           - Juan Velasco                     */
/*                                              */
/*  Made by: Daniel Santo-Tomás                 */
/************************************************/

#ifndef DANI_H
#define DANI_H

#include "interface.h"


int main_dani(Interface *i);

int dani(Interface *i);

#endif
